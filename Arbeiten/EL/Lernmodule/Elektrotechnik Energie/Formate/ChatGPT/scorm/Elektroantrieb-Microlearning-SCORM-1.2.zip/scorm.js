(function(){
'use strict';
var api=null,active=false,finished=false,seen={},sections=[],start=Date.now();
function find(w){for(var i=0;w&&i<100;i++){try{if(w.API)return w.API;if(w.parent===w)break;w=w.parent;}catch(e){break;}}return null;}
try{api=find(window);if(!api&&window.opener)api=find(window.opener);}catch(e){}
function call(method,a){try{return api?api[method](a):'false';}catch(e){return 'false';}}
function persist(){if(!active||finished)return;try{api.LMSSetValue('cmi.suspend_data',JSON.stringify(Object.keys(seen)));if(sections.every(function(s){return seen[s.id];})){api.LMSSetValue('cmi.core.lesson_status','completed');}api.LMSCommit('');}catch(e){}}
function stop(){if(!active||finished)return;persist();var t=Math.floor((Date.now()-start)/1000),h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;try{api.LMSSetValue('cmi.core.session_time',String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'));api.LMSSetValue('cmi.core.exit',sections.every(function(x){return seen[x.id];})?'':'suspend');api.LMSCommit('');}catch(e){}call('LMSFinish','');finished=true;}
function init(){sections=Array.from(document.querySelectorAll('section.section'));if(api&&String(call('LMSInitialize',''))==='true'){active=true;var status=call('LMSGetValue','cmi.core.lesson_status');if(!status||status==='not attempted')api.LMSSetValue('cmi.core.lesson_status','incomplete');try{JSON.parse(call('LMSGetValue','cmi.suspend_data')||'[]').forEach(function(id){seen[id]=true;});}catch(e){}api.LMSCommit('');}
function check(){sections.forEach(function(el){var r=el.getBoundingClientRect();if(r.top<window.innerHeight*.85&&r.bottom>window.innerHeight*.15)seen[el.id]=true;});persist();}
check();window.addEventListener('scroll',check,{passive:true});window.addEventListener('resize',check);window.addEventListener('pagehide',stop);window.addEventListener('beforeunload',stop);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
