(function () {
'use strict';
const pages = ['index.html', ...Array.from({length:22}, (_,i) => 'folie-' + String(i+2).padStart(2,'0') + '.html')];
const visited = new Set();
let api = null, active = false, ended = false, completed = false, current = 1;
let started = Date.now();
const status = document.getElementById('connection');
function find(start) {
  const seen = new Set();
  let w = start;
  for (let i=0; w && i<100 && !seen.has(w); i++) {
    seen.add(w);
    try { if(w.API && typeof w.API.LMSInitialize === 'function') return w.API;
      if(w.parent && w.parent !== w) { w=w.parent; continue; }
      w=w.opener;
    } catch(e) { break; }
  }
  return null;
}
function call(name, ...args) { try { return api[name](...args); } catch(e) { return 'false'; } }
function ok(v) { return v === true || v === 'true'; }
function get(key) { const v=call('LMSGetValue',key); return typeof v==='string' && v!=='false' ? v : ''; }
function time() {
  const cs=Math.min(3599999999,Math.floor((Date.now()-started)/10));
  return String(Math.floor(cs/360000)).padStart(4,'0')+':'+String(Math.floor(cs/6000)%60).padStart(2,'0')+':'+String(Math.floor(cs/100)%60).padStart(2,'0')+'.'+String(cs%100).padStart(2,'0');
}
function render() {
  const count=[...visited].filter(n=>n<=22).length;
  if(count===22) completed=true;
  document.getElementById('progress').textContent = completed ? 'Abgeschlossen · 22 von 22 Pflichtseiten besucht' : count+' von 22 Pflichtseiten besucht';
  document.getElementById('bar').value=count;
}
function save() {
  if(!active || ended) return false;
  let success=true;
  const values={
    'cmi.suspend_data':JSON.stringify({v:1,visited:[...visited].sort((a,b)=>a-b)}),
    'cmi.core.lesson_location':pages[current-1],
    'cmi.core.lesson_status':completed?'completed':'incomplete',
    'cmi.core.session_time':time(),
    'cmi.core.exit':'suspend'
  };
  Object.entries(values).forEach(([key,value])=>{if(!ok(call('LMSSetValue',key,value))) success=false;});
  if(!ok(call('LMSCommit',''))) success=false;
  status.textContent=success?'Im LMS gespeichert':'Speichern fehlgeschlagen – bitte erneut versuchen.';
  return success;
}
window.WolkenTracking={visit(n) {
  if(ended || !Number.isInteger(n) || n<1 || n>23) return;
  current=n; visited.add(n); render(); save();
}};
api=find(window);
if(!api) { try { api=find(window.opener); } catch(e) {} }
if(api) active=ok(call('LMSInitialize',''));
if(active) {
  const entry=get('cmi.core.entry');
  if(entry!=='ab-initio') {
    try { const data=JSON.parse(get('cmi.suspend_data')); if(data.v===1 && Array.isArray(data.visited)) data.visited.forEach(n=>{if(Number.isInteger(n)&&n>=1&&n<=23)visited.add(n);}); } catch(e) {}
    const index=pages.indexOf(get('cmi.core.lesson_location')); if(index>=0) current=index+1;
    completed=['completed','passed'].includes(get('cmi.core.lesson_status'));
  }
  status.textContent='Mit LMS verbunden';
} else status.textContent=api?'LMS-Verbindung fehlgeschlagen – Fortschritt wird nicht gespeichert.':'Vorschau ohne LMS – Fortschritt wird nicht dauerhaft gespeichert.';
render();
document.getElementById('content').src=pages[current-1];
function finish() {
  if(ended) return true;
  if(active) {
    if(!save()) return false;
    if(!ok(call('LMSFinish',''))) {status.textContent='Beenden fehlgeschlagen – bitte erneut versuchen.';return false;}
  }
  ended=true; active=false; return true;
}
document.getElementById('finish').addEventListener('click',()=>{
  if(!finish())return;
  document.getElementById('content').hidden=true;
  document.getElementById('finish').disabled=true;
  status.textContent=api?'Gespeichert und beendet. Du kannst das Modul jetzt schliessen.':'Vorschau beendet. Du kannst das Modul jetzt schliessen.';
});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')save();});
window.addEventListener('pagehide',finish);
window.addEventListener('beforeunload',()=>{save();});
window.addEventListener('pageshow',e=>{if(e.persisted && ended)window.location.reload();});
setInterval(save,30000);
})();
