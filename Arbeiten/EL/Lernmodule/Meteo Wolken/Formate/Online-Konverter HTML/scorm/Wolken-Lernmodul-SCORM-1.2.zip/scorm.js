(function () {
  'use strict';
  var slides = Array.from(document.querySelectorAll('.slide'));
  var ids = slides.map(function (s) { return s.querySelector('svg').id; });
  var api = null, active = false, finished = false, visited = new Set(), current = ids[0];
  var started = Date.now();
  function find(w) {
    for (var i = 0; w && i < 100; i++) {
      try { if (w.API) return w.API; if (w.parent === w) break; w = w.parent; } catch (e) { break; }
    }
    return null;
  }
  api = find(window);
  if (!api) { try { api = find(window.opener); } catch (e) {} }
  function get(k) { try { return active ? api.LMSGetValue(k) : ''; } catch (e) { return ''; } }
  function set(k, v) { if (active) api.LMSSetValue(k, String(v)); }
  function commit() { if (active) api.LMSCommit(''); }
  try { active = !!api && String(api.LMSInitialize('')) === 'true'; } catch (e) {}
  var completed = get('cmi.core.lesson_status') === 'completed';
  try {
    var saved = JSON.parse(get('cmi.suspend_data') || '{}');
    (saved.visited || []).forEach(function (id) { if (ids.indexOf(id) >= 0) visited.add(id); });
  } catch (e) {}
  var bookmark = get('cmi.core.lesson_location');
  function save() {
    completed = completed || visited.size === ids.length;
    set('cmi.suspend_data', JSON.stringify({visited: Array.from(visited)}));
    set('cmi.core.lesson_location', current);
    set('cmi.core.lesson_status', completed ? 'completed' : 'incomplete');
    set('cmi.core.exit', completed ? '' : 'suspend');
    commit();
  }
  function show(id) {
    if (ids.indexOf(id) < 0) return;
    current = id;
    slides.forEach(function (s, i) { s.hidden = ids[i] !== id; });
    visited.add(id);
    save();
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a');
    if (!a) return;
    var href = a.getAttribute('href') || a.getAttribute('xlink:href') || '';
    if (href.charAt(0) === '#' && ids.indexOf(href.slice(1)) >= 0) {
      e.preventDefault(); show(href.slice(1));
    }
  });
  document.addEventListener('keydown', function (e) {
    var i = ids.indexOf(current);
    if (e.key === 'ArrowRight' && i < ids.length - 1) { e.preventDefault(); show(ids[i + 1]); }
    if (e.key === 'ArrowLeft' && i > 0) { e.preventDefault(); show(ids[i - 1]); }
  });
  window.addEventListener('hashchange', function () { show(location.hash.slice(1)); });
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') save(); });
  function finish() {
    if (finished || !active) return;
    save();
    var cs = Math.floor((Date.now() - started) / 10);
    var h = Math.floor(cs / 360000), m = Math.floor(cs / 6000) % 60, sec = Math.floor(cs / 100) % 60;
    set('cmi.core.session_time', String(h).padStart(4, '0') + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0') + '.' + String(cs % 100).padStart(2, '0'));
    commit(); api.LMSFinish(''); active = false; finished = true;
  }
  window.addEventListener('pagehide', function (e) { if (!e.persisted) finish(); else save(); });
  window.addEventListener('beforeunload', finish);
  show(ids.indexOf(bookmark) >= 0 ? bookmark : ids[0]);
})();
